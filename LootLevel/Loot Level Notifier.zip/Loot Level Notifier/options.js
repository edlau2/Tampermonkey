function save_options() {
  console.log("Saving Loot Level options");
  var watchDuke = document.getElementById('Duke').checked;
  var watchLeslie = document.getElementById('Leslie').checked;
  var lvlI = document.getElementById('I').checked;
  var lvlII = document.getElementById('II').checked;
  var lvlIII = document.getElementById('III').checked;
  var lvlIV = document.getElementById('IV').checked;
  var lvlV = document.getElementById('V').checked;
  var hospTime = document.getElementById('hosp').checked;
  var timeout = document.getElementById("notifyTimeout").value;
  var checkFrequency = document.getElementById("frequency").value;
  var nextLevel = document.getElementById("nextLevel").checked;
  var levelIV = document.getElementById("levelIV").checked;
  chrome.storage.sync.set({
    Duke: watchDuke,
    Leslie: watchLeslie,
    levelI: lvlI,
    levelII: lvlII,
    levelIII: lvlIII,
    levelIV: lvlIV,
    levelV: lvlV,
    hosp: hospTime,
    notifyTimeout: timeout, // Seconds
    frequency: checkFrequency, // Minutes, unused
    nextLevel: nextLevel,
    levelIV: levelIV
  }, function() {
    // Update status to let user know options were saved.
    var status = document.getElementById('status');
    status.innerHTML = '<font color="red">Options saved!</font><br><br>';
    console.log("Saved options: Duke=" + watchDuke + " Leslie=" + watchLeslie);
    setTimeout(function() {
      status.textContent = '';
    }, 2000);
  });
}

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
function restore_options() {
  // Use default values, watch all NPC's
  chrome.storage.sync.get({
    Duke: true,
    Leslie: true,
    levelI: true,
    levelII: true,
    levelIII: true,
    levelIV: true,
    levelV: true,
    hosp: true,
    notifyTimeout: 10, // seconds
    frequency: 1, // minutes, unused
    nextLevel: true,
    levelIV: false
  }, function(items) {
    document.getElementById("Duke").checked = items.Duke;
    document.getElementById("Leslie").checked = items.Leslie;
    document.getElementById("I").checked = items.levelI;
    document.getElementById("II").checked = items.levelII;
    document.getElementById("III").checked = items.levelIII;
    document.getElementById("IV").checked = items.levelIV;
    document.getElementById("V").checked = items.levelV;
    document.getElementById("hosp").checked = items.hosp;
    document.getElementById("notifyTimeout").value = items.notifyTimeout;
    document.getElementById("frequency").value = items.frequency;
    document.getElementById("nextLevel").checked = items.nextLevel;
    document.getElementById("levelIV").checked = items.levelIV;
  });
}

window.onload = function(){
           //window.addEventListener("load", restore_options);
           document.addEventListener("DOMContentLoaded", restore_options);
           document.getElementById("save").addEventListener('click', save_options);
           restore_options();
        };


