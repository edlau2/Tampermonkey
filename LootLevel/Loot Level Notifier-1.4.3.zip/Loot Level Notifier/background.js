/*************************************************************************************/
/*
/* Torn Loot Level Notifier
/* Version 1.2, 08/05/2019
/* xedx [2100735]
/*
/* This Chrome extension display notifications when Torn NPC's go through a status
/* change. THis is configurable via an Options menu.
/* 
/* You can be notified when in hospital, which displays the time when they are getting
/* out of hospital. You can display when at any Loot Level, I, II, III, IV, or IV. This
/* will also display either the time when at the next level, the time until the next
/* level, or the time (relative) until the next level or until level IV.
/*
/* Presently, the status is checked every minute. THe duration that the notification 
/* is displayed for is configurable, but can be closed at any time. There is also a
/* button provided to jump to the attack page immediately from the notification.
/* 
/* Please direct any issues (bugs), suggestions, requests, etc. to me via a message
/* or PM in Torn - xedx [2100735].
/*
/* Repository link: https://github.com/edlau2/Tampermonkey#extensions
/*
/*************************************************************************************/

/*************************************************************************************/
/*
/* Startup: Create our 1-minute alarm to fire off our API call and notifications
/*
/*************************************************************************************/

chrome.alarms.create(
  "xedx-loot-level", 
  {
    delayInMinutes: 1,
    periodInMinutes: 1
  }
);

chrome.alarms.onAlarm.addListener(function(alarm) {
  if (alarm.name === "xedx-loot-level") {
    onAlarm();
  }
});

/*
// TEST handler, use to implement asyn ImportJSON()
chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    console.log(sender.tab ?
                "Message from a content script:" + sender.tab.url :
                "Message from the extension");
    if (validPointer(request)) {
      if (request.greeting == "hello") {
        sendResponse({farewell: "goodbye"});
      }
    }
  });

// Test 2
chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
  chrome.tabs.sendMessage(tabs[0].id, {greeting: "hello"}, function(response) {
    if (validPointer(response)) {
      console.log(response.farewell);
    }
  });
});

function testFunc() {
  console.log("Test Function Called");
}

chrome.runtime.onConnect.addListener(function(port) {
  console.log("addListener" + msg);
  port.onMessage.addListener(function(msg) {
    // Handle message however you want
    console.log("Message Received" + msg);
  })
});
*/

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => sendResponse('pong'));

// Launch right away, don't wait for first call This is mostly for debugging.
// Makes finding syntactical errors quicker. This call also ensures that the
// user has entered their API key.
console.log(current_time() + ": Starting Loot Level Notifier extension!");
onAlarm();



/*************************************************************************************/
/*
/* Global variables used throughout the program
/*
/************************************************************************************/

// Time put in hosp and time left until out
var dukeInHosp = null;
var leslieInHosp = null;
var dukeOutOfHosp = null;
var leslieOutOfHosp = null;

// Times we hit certain levels. Used if we miss hosp time.
var dukeHitLvl1 = null;
var dukeHitLvl2 = null;
var dukeHitLvl3 = null;
var dukeHitLvl4 = null;
var dukeHitLvl5 = null;

var leslieHitLvl1 = null;
var leslieHitLvl2 = null;
var leslieHitLvl3 = null;
var leslieHitLvl4 = null;
var leslieHitLvl5 = null;

var haveAttacked = [{'Duke':   false, 
                     'Leslie': false}];

// THe NPC's we are interested in
var userIDs = 
    [{name: 'Duke',       ID: '4',  statusCell: 'C2', lvlCell: 'D2', lifeStr: '', enabled: true}, 
     {name: 'Leslie',     ID: '15', statusCell: 'C3', lvlCell: 'D3', lifeStr: '', enabled: true}];

var hospDatas =
    [{name: 'Duke',   inHosp: false, hoursLeft: 0, minsLeft: 0, secsLeft: 0, nextLvlTime: 0, toLvl4time: 0},
     {name: 'Leslie', inHosp: false, hoursLeft: 0, minsLeft: 0, secsLeft: 0, nextLvlTime: 0, toLvl4time: 0}]

// Mis options configured via the Options HTML and associated .js
// Note that we don't actually have to declare here, as long as we
// create in the loadOptions function, they wil be added automatically.
// I do this for clarity.
var options = 
  {
  'apiKey': "",
  'notifyHosp': true,
  'notifyLvlI': true,
  'notifyLvlII': true,
  'notifyLvlIII': true,
  'notifyLvlIV': true,
  'notifyLvlV': true,
  'notifyTimeout': 10, // In seconds
  'frequency': 1, // minutes, unused
  'nextLevel': true,
  'atLevelIV': false,
  'untilLevelIV': false,
  'autoAttack': false
  };

  // Data gleaned when in hosp
  //var hospData = {inHosp: false, hoursLeft: 0, minsLeft: 0, secsLeft: 0, nextLvlTime: 0, toLvl4time: 0};

/*************************************************************************************/
/*
/* Utility functions
/*
/************************************************************************************/

// Check a ptr for undefined/null
function validPointer(val, dbg = false) {
  if (val == 'undefined' || typeof val == 'undefined' || val == null) {
    if (dbg) {
      // debugger; // Is this supported in extensions?
    }
      return false;
    }
        
    return true;
} 

// Return current time string
function current_time() {
 return new Date().toLocaleTimeString(); 
}

// Take a possible string, convert to an INT, set to zero if empty string
function strToNum(num) {
  var ret = 0;
  if (num == "" || parseInt(num) == 'NaN') {
    return 0;
  }

  return parseInt(num);
}

// Left-pad a number with zeros, up to size, defaults to 2
Number.prototype.pad = function(size) {
    var s = String(this);
    while (s.length < (size || 2)) {s = "0" + s;}
    return s;
}

// Take hrs, mins, secs and return as HH:MM:SS
function toHhMmSs(hrs, mins, secs) {
  hrs = strToNum(hrs).pad();
  mins = strToNum(mins).pad();
  secs = strToNum(secs).pad();

 return hrs + ":" + mins + ":" + secs;
}

//Determine if an object is numeric
var isNumeric = function(obj) {
  return !Array.isArray( obj ) && (obj - parseFloat( obj ) + 1) >= 0;
}

// Convert milliseconds to HH:MM:SS
function msToTime(duration) {
  var milliseconds = parseInt((duration % 1000) / 100),
    seconds = Math.floor((duration / 1000) % 60),
    minutes = Math.floor((duration / (1000 * 60)) % 60),
    hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

  // Padding...
  hours = (hours < 10) ? "0" + hours : hours;
  minutes = (minutes < 10) ? "0" + minutes : minutes;
  seconds = (seconds < 10) ? "0" + seconds : seconds;

  if (hours < 0 || minutes < 0 || seconds < 0) {
    console.log(current_time() + ": uh-oh! " + toHhMmSs(hours, minutes, seconds)); // Break here...
  }

  return hours + ":" + minutes + ":" + seconds; // + "." + milliseconds;
}

// Subtract two dates, return as HH:MM:SS
// date2 - date2
function dateDifference(date1, date2) {
  var futureDate = date2.getTime();
  var pastDate = date1.getTime();
  var diff = futureDate - pastDate;

  return msToTime(diff);
}

/*************************************************************************************/
/*
/* Torn API query functions
/*
/* Note: At present,these are synchronous XMLHttpRequest calls, in ImportJSON.js
/* Should be converted to async calls with async complete handlers.
/*
/* To implement here, switch to async in ImportJSON, and end the loadOptionsComplete()
/* async handler right after these calls; create a new async handler with the rest 
/* of the code that follows and call it from the handler in ImportJSON.
/*
/************************************************************************************/

// Query the players Profile data
function buildLifeString(userId) {
  var lifeCurr = 0;
  var lifeMax = 0;
  var lifeStr = "";
  var query = "";

  url = "https://api.torn.com/user/" + userId.ID + "?selections=profile&key=" + options.apiKey;
  value = ImportJSON(url, query, "noHeaders,noTruncate");
  if (value != null) {
    lifeCurr = value[0][16];
    lifeMax = value[0][17];

    // Debugging - might not need to query 'basic'
    var dbgLootLvl = value[0][22]; // Same as statusStr? Seems to be
    var dbgMisc = value[0][23];

    lifeStr = lifeCurr + "/" + lifeMax;
  }

  userId.lifeStr = lifeStr;
}

// Query the players Basic data
function queryBasicStats(userId) {
  var ID = userId.ID;
  var query = "";
  var url = "https://api.torn.com/user/" + ID + "?selections=basic&key=" + options.apiKey;
  var value = ImportJSON(url, query, "noHeaders,noTruncate");     

  // We should make from here a 'importJsonComplete()' fn,
  // and call when async XMLHttpRequest completes.
  // eg: function inportJsonComplete(...) { 

  // Check for errors, specifically 'Invalid API key'
  if (!validPointer(value)) {
    return null;
    }

  if (value.length == 1) {
    var errCode = value[0][0];
    var errStr = value[0][1];
    if (isNumeric(errCode)) {
      console.log(current_time() + ": query returned error: code=" + errCode + " error=\'" + errStr + "\'");
    
      if (errCode == 2 || errStr == 'Incorrect key') {
        alert("Invalid API key! Please enter in the Options page.");
        options.apiKey = null;
        validateApiKey();
      }
    return null;
    }
  }

  statusStr = value[0][4];
  if (!validPointer(statusStr)) {
    return null;
    }

  return statusStr;
}

/*************************************************************************************/
/*
/* Validation. This ensures that a valid API key is present, and kicks off
/* the main program right away, before the first 1-minute alarm goes off.
/*
/************************************************************************************/

function validateApiKey() {
  if (options.apiKey === '' || options.apiKey == null) {
    console.log(current_time() + ": Launching options dialog, NULL API key.");
    chrome.runtime.openOptionsPage();
    return false;;
  }

  console.log(current_time() + ": validateApiKey, key present (\'" + options.apiKey + ")\'");
  return true;
}

/*************************************************************************************/
/*
/* Where the work is done This function is called when the alarm gos off. It loads
/* options, which is an async call - it fires of the async complete handler - the
/* loadOptionsComplete function.
/*
/************************************************************************************/

function onAlarm() {
  console.log(current_time() + ": onAlarm");

  // This call is async, so we can't do any real work until it completes.
  loadOptions();
}
 
 // Async complete handler for loadOptions()
function loadOptionsComplete() {
  console.log(current_time() + ": loadOptionsComplete");
  if (!validateApiKey()) {
    return;
  }

  var notificationDetails = {
    type: "basic",
    title: "Loot Level Checker",
    message: "Primary message to display",
    iconUrl: "icon_128.png"
  };
  
  for (var i = 0; i<userIDs.length; i++) {
    // See if our options are configured to display for this NPC
    if (userIDs[i].enabled == false) {
      console.log(current_time() + ": Notifications not enabled for NPC " + 
                  userIDs[i].name);
      continue;
    }

    // Query basic stats to get NPC's status         
    var statusStr = queryBasicStats(userIDs[i]);
    if (!validPointer(statusStr)) {
      //continue;
      return; // 'null' is returned on error, usually indicates invalid key or server error.
    }

    // Do same to get life current/max
    buildLifeString(userIDs[i]);
    var lifeStr = userIDs[i].lifeStr;

    // If in the hospital, calculate time in, time out, HH:MM:SS left
    var hospData; // = {inHosp: false, hoursLeft: 0, minsLeft: 0, secsLeft: 0, nextLvlTime: 0, toLvl4time: 0};
    if (userIDs[i].name == 'Duke') {
      hospData = hospDatas[0]; 
    } else {
      hospData = hospDatas[1]; 
    }
    parseHospData(statusStr, hospData, userIDs[i]);

// <== Factor this out

    // Log this event and save time until released.
    if (hospData.inHosp) {
      if (hospData.hoursLeft > 0) {
        notificationDetails.message = userIDs[i].name + ' is in hosp for ' +
              hospData.hoursLeft + ' hours, ' + hospData.minsLeft + ' minutes.';
      } else if (hospData.minsLeft > 0) {
        notificationDetails.message = userIDs[i].name + ' is in hosp for ' +
              hospData.minsLeft + ' minutes.';
      } else if (hospData.secsLeft > 0) {
        notificationDetails.message = userIDs[i].name + ' is in hosp for ' +
              hospData.secsLeft + ' seconds.';
      }

      console.log(current_time() + ": " + notificationDetails.message);  
      var now = new Date();
      now.setMinutes(now.getMinutes() + hospData.minsLeft + hospData.hoursLeft*60);
      console.log(current_time() + ": Added " + (hospData.minsLeft + hospData.hoursLeft*60) + 
          " minutes, new time: " + now.toLocaleTimeString());

      if (userIDs[i].name == "Duke") {
        if (dukeInHosp == null) {
          dukeInHosp = new Date();
          console.log(current_time() + ": set dukeInHosp to " +
                      dukeInHosp.toLocaleTimeString()); 
        }
        dukeOutOfHosp = new Date(now.getTime());  
        console.log(current_time() + ": set dukeOutOfHosp to " +
          dukeOutOfHosp.toLocaleTimeString()); 
        } else {
          if (leslieInHosp == null) {
            leslieInHosp = new Date();
            console.log(current_time() + ": set leslieInHosp to " +
                      leslieInHosp.toLocaleTimeString()); 
          }
        leslieOutOfHosp = new Date(now.getTime()); 
        console.log(current_time() + ": set leslieOutOfHosp to " +
          leslieOutOfHosp.toLocaleTimeString());
      } 
    } else {
      // Diagnostic vars
      if (userIDs[i].name == "Duke") {
        dukeInHosp = null;   
      } else {
        leslieInHosp = null; 
      } 
      hospData.inHosp = false;
    } // end if (inHosp)

  // <== End factor out

    end = statusStr.indexOf(',');
    var status = statusStr;
    var lootLvl = '<unknown loot level>';
    if (end != -1) {
      status = statusStr.slice(0, end);
      lootLvl = statusStr.slice(end+1);
    }
    
    if (!hospData.inHosp) {
      notificationDetails.title = userIDs[i].name + ' is at ' + lootLvl;
    } else {
      notificationDetails.title = "Loot Level Checker";
    }
    console.log(current_time() + ": onAlarm: raw data (statusStr) = " + statusStr);
    console.log(current_time() + ": onAlarm: message = " 
                + notificationDetails.message);

    var iconUrlStr = "icon_128.png";
    if (userIDs[i].name == "Duke") {
      iconUrlStr = "https://profileimages.torn.com/50c3ed98-ae8f-311d-4.png";
    } else if (userIDs[i].name == "Leslie") {
      iconUrlStr = "https://profileimages.torn.com/4d661456-746e-b140-15.png";
    }

    // loot levels increase after 30, 90, 210 and 450 minutes.
    // Get the time until next loot level, for display - if
    // this return 0, we aren't tracking current loot level.
    var ret = getNextLootLevelInc(lootLvl, hospData, userIDs[i]);
    if (ret == -1 || hospData.nextLvlTime == -1 || (hospData.inHosp && !options.notifyHosp)) {
      if (!options.notifyHosp && !options.notifyHosp) {
        console.log(current_time() + ": Not notifying, in hosp");
      }
      continue;
    }

    // If configured to auto-attack, launch now if needed
    if (lootLvl == 'Loot level IV' && options.autoAttack) {
        var key = userIDs[i].name;
        if (!haveAttacked[key]) {
          var url = "https://www.torn.com/loader.php?sid=attack&user2ID=" +
            userIDs[i].ID;
          console.log(current_time() + ": Launching URL: " + url);
          chrome.tabs.create({url: url});
          haveAttacked[key] = true;
      }
    }

    // Build our strings based on next level times
    var nextLvlStruct = {nextLvlStr: "", nextLvl: null, lifeStr: lifeStr, lootLvl: lootLvl,
                         nextLvlTime: hospData.nextLvlTime, toLvl4time: hospData.toLvl4time};
    buildLevelStrings(userIDs[i], nextLvlStruct, hospData, notificationDetails);

    console.log(current_time() + ": Creating notification, Title: " +
                notificationDetails.title + '\nMessage: ' +
                notificationDetails.message);
    chrome.notifications.getPermissionLevel(permissionLevelCallback);
    chrome.notifications.onButtonClicked.addListener(onClickCallback);
    chrome.notifications.onClosed.addListener(onClickCallback);
    chrome.notifications.create(userIDs[i].name, 
                                {type: "basic",
                                 title: notificationDetails.title,
                                 message: notificationDetails.message,
                                 iconUrl: iconUrlStr,
                                 requireInteraction: true,
                                 buttons: [{
                                    title: "Attack"
                                  },
                                  {
                                    title: "Options"
                                  }]
                                },
                                creationCallback);
  } // end 'for' loop
}

/*************************************************************************************/
/*
/* Misc. callbacks for the notification functions
/*
/************************************************************************************/

function creationCallback(id) {
  if (validPointer(chrome.runtime.lastError)) {
    var text = current_time() + ": Creating notification for " + id + 
               ", lastError = " + chrome.runtime.lastError;
    console.log(current_time() + ": " + text);
  }

  // Automatically close/clear after 10 seconds
  setTimeout(function(){
    console.log(current_time() + ": notification timing out (closing), id = " + id);
    chrome.notifications.clear(id);}, options.notifyTimeout*1000);
}

function onClickCallback(id, index) {
  console.log(current_time() + ": notification onClickCallback" +
                               " ID=" + id + " Index=" + index);
  if (index == 0) { // Attack button
    var done = false;
    for (var i = 0; i<userIDs.length && !done; i++) {
      if (userIDs[i].name == id) {
        var url = "https://www.torn.com/loader.php?sid=attack&user2ID=" +
          userIDs[i].ID;
        console.log(current_time() + ": Launching URL: " + url);
        chrome.tabs.create({url: url});
        done = true;
      }
    }
  } else if (index == 1) { // Options button
    console.log(current_time() + ": Launching options dialog.");
    chrome.runtime.openOptionsPage();
  }
}

function permissionLevelCallback(level) {
  console.log(current_time() + ": notification permission level = " + level);
}

/*************************************************************************************/
/*
/* Functions to parse data when in hosp.
/*
/************************************************************************************/

function parseHospData(statusStr, hospData, userId){
  //var hospData = {name, inHosp: false, hoursLeft: 0, minsLeft: 0, secsLeft: 0};
  if (userId.name != hospData.name) {
    console.log(current_time() + ": oops - invalid params"); // Break here
  }

  var end = -1;
  var start = -1;
  var hoursLeft = 0;
  var minsLeft = 0;
  var secsLeft = 0;
  if ((start = statusStr.indexOf('In hospital for ')) != -1) {
    hospData.inHosp = true;
    end = statusStr.indexOf(' hrs ');
    if (end != -1) {
      hoursLeft = statusStr.slice(start+16, end);
      start = end+5;
      end = statusStr.indexOf(' mins');
      if (end != -1) {
         minsLeft = statusStr.slice(start, end);
      }
    } else {
      end = statusStr.indexOf(' mins');
      if (end != -1) {
         minsLeft = statusStr.slice(start+16, end);
         start = end+5;
         end = statusStr.indexOf(' secs');
         if (end != -1) {
           secsLeft = statusStr.slice(start, end);
         }
      } else {
        end = statusStr.indexOf(' secs');
        if (end != -1) {
          secsLeft = statusStr.slice(start+16, end);
        }
      }
    }

    hospData.hoursLeft = strToNum(hoursLeft);
    hospData.minsLeft = strToNum(minsLeft);
    hospData.secsLeft = strToNum(secsLeft);
  }
}

/*************************************************************************************/
/*
/* Functions to figure out times for next loot levels, create notification strings
/* Loot levels increase after 30, 90, 210 and 450 minutes.
/*
/************************************************************************************/

// Retunrs -1 if we don't notify for this loot level
function getNextLootLevelInc(lootLvl, hospData, userId) {
  if (userId.name != hospData.name) {
    console.log(current_time() + ": oops - invalid params"); // Break here
  }

  var nextLvlTime = 0;
  var toLvl4time = 0;

  // Reset auto-attack
  var key = userId.name;
  if (lootLvl != 'Loot level IV') {
    haveAttacked[key] = false;
  }

  if (lootLvl == 'Loot level I') {
    if (!options.notifyLvlI) {
      console.log(current_time() + ": Not notifying, lvl I");
      return 0;
    }
    nextLvlTime = 30;
    toLvl4time = 30 + 90 + 210;
  }
  if (lootLvl == 'Loot level II') {
    if (!options.notifyLvlII) {
      console.log(current_time() + ": Not notifying, lvl II");
      return -1;
    }
  nextLvlTime = 90;
  toLvl4time = 90 + 210;
  }
  if (lootLvl == 'Loot level III') {
    if (!options.notifyLvlIII) {
      console.log(current_time() + ": Not notifying, lvl III");
      return -1;
    }
  nextLvlTime = 210;
  toLvl4time = 210;
  }
  if (lootLvl == 'Loot level IV') {
    if (!options.notifyLvlIV) {
      console.log(current_time() + ": Not notifying, lvl IV");
      return -1;
    }
  nextLvlTime = 450;
  }
  if (lootLvl == 'Loot level V' && !options.notifyLvlV) {
    console.log(current_time() + ": Not notifying, lvl V");
    return -1;
  }

  hospData.toLvl4time = toLvl4time;
  hospData.nextLvlTime = nextLvlTime;
}

//var nextLvlStruct = {nextLvlStr: "", nextLvl: null, lifeStr: lifeStr};  
//
// Try to figure out when we hit the next level. If we've been running since a hosp,
// we can get it from that. If not, we can try to toggle at a level change.
//
// We may be configured to instead display time until level IV, take that into consideration.
function buildLevelStrings(userId, nextLvlStruct, hospData, notificationDetails) {
  var nextLvlStr = null;
  var nextLvl = null;
  var toLvl4 = null;
  var lootLvl = nextLvlStruct.lootLvl;
  var timeLeftStr = null;

  if (userId.name != hospData.name) {
    console.log(current_time() + ": oops - invalid params"); // Break here
  }

  if (userId.name == "Duke" && validPointer(dukeOutOfHosp)) {
    timeLeftStr = toHhMmSs(hospData.hoursLeft, hospData.minsLeft, hospData.secsLeft);
    nextLvlStr = dukeOutOfHosp.toLocaleTimeString();
    nextLvl = new Date(dukeOutOfHosp.getTime());
    toLvl4 = new Date(dukeOutOfHosp.getTime());
    nextLvl.setMinutes(nextLvl.getMinutes() + hospData.nextLvlTime);
    toLvl4.setMinutes(nextLvl.getMinutes() + hospData.toLvl4time);
    if (hospData.inHosp) {
      notificationDetails.title = userId.name + " in hosp: " + timeLeftStr;
      }
    notificationDetails.message = 'Next level at ' + nextLvl.toLocaleTimeString(); 
  } else if (userId.name == "Leslie" && validPointer(leslieOutOfHosp)) {
    timeLeftStr = toHhMmSs(hospData.hoursLeft, hospData.minsLeft, hospData.secsLeft);
    nextLvlStr = leslieOutOfHosp.toLocaleTimeString();
    nextLvl = new Date(leslieOutOfHosp.getTime());
    toLvl4 = new Date(leslieOutOfHosp.getTime());
    nextLvl.setMinutes(nextLvl.getMinutes() + hospData.nextLvlTime);
    toLvl4.setMinutes(nextLvl.getMinutes() + hospData.toLvl4time);
    if (hospData.inHosp) {
     notificationDetails.title = userId.name + " in hosp: " + timeLeftStr;
    }
  }

  // If we didn't get hosp time data, try our best to catch level triggers.
  // loot levels increase after 30, 90, 210 and 450 minutes.
  if (nextLvl == null) {
    if (userId.name == 'Duke') {
      var timeIncMins = 0;
      var toLvl4Mins = 0;
      var useTime = null;
      switch (lootLvl) {
        case 'Loot level I':
          if (dukeHitLvl1 == null) {
            dukeHitLvl1 = new Date();
          }
          nextLvl = new Date(dukeHitLvl1.getTime());
          toLvl4 = new Date(dukeHitLvl1.getTime());
          toLvl4Mins = 30 + 90 + 210;
          timeIncMins = 30;
          break;
        case 'Loot level II':
          if (dukeHitLvl2 == null) {
            dukeHitLvl2 = new Date();
          }
          dukeHitLvl1 = null;
          nextLvl = new Date(dukeHitLvl2.getTime());
          toLvl4 = new Date(dukeHitLvl2.getTime());
          toLvl4Mins = 90 + 210;
          timeIncMins = 90;
          break;
        case 'Loot level III':
          if (dukeHitLvl3 == null) {
            dukeHitLvl3 = new Date();
          }
          dukeHitLvl2 = null;
          nextLvl = new Date(dukeHitLvl3.getTime());
          toLvl4 = new Date(dukeHitLvl3.getTime());
          toLvl4Mins = 210;
          timeIncMins = 210;
          break;
        case 'Loot level IV':
          if (dukeHitLvl4 == null) {
            dukeHitLvl4 = new Date();
          }
          dukeHitLvl3 = null;
          nextLvl = new Date(dukeHitLvl4.getTime());
          toLvl4 = new Date(dukeHitLvl4.getTime());
          timeIncMins = 450;
          break;
        case 'Loot level V':
          if (dukeHitLvl5 == null) {
            dukeHitLvl5 = new Date();
          }
          dukeHitLvl4 = null;
          nextLvl = new Date(dukeHitLvl5.getTime());
          toLvl4 = new Date(dukeHitLvl5.getTime());
          timeIncMins = 0;
          break;
        default:
          dukeHitLvl1 = dukeHitLvl2 = dukeHitLvl3 = dukeHitLvl4 = dukeHitLvl5 = null;
      }

      if (nextLvl != null) {
        nextLvl.setMinutes(nextLvl.getMinutes() + timeIncMins);
      }
      if (toLvl4 != null) {
        toLvl4.setMinutes(nextLvl.getMinutes() + toLvl4Mins);
      }
    } else if (userId.name == 'Leslie') {
      var timeIncMins = 0;
      var useTime = null;
      switch (lootLvl) {
        case 'Loot level I':
          if (leslieHitLvl1 == null) {
            leslieHitLvl1 = new Date();
          }
          nextLvl = new Date(leslieHitLvl1.getTime());
          toLvl4 = new Date(leslieHitLvl1.getTime());
          toLvl4Mins = 30 + 90 + 210;
          timeIncMins = 30;
          break;
        case 'Loot level II':
          if (leslieHitLvl2 == null) {
            leslieHitLvl2 = new Date();
          }
          leslieHitLvl1 = null;
          nextLvl = new Date(leslieHitLvl2.getTime());
          toLvl4 = new Date(leslieHitLvl2.getTime());
          toLvl4Mins = 90 + 210;
          timeIncMins = 90;
          break;
        case 'Loot level III':
          if (leslieHitLvl3 == null) {
            leslieHitLvl3 = new Date();
          }
          leslieHitLvl2 = null;
          nextLvl = new Date(leslieHitLvl3.getTime());
          toLvl4 = new Date(leslieHitLvl3.getTime());
          toLvl4Mins = 210;
          timeIncMins = 210;
          break;
        case 'Loot level IV':
          if (leslieHitLvl4 == null) {
            leslieHitLvl4 = new Date();
          }
          leslieHitLvl3 = null;
          nextLvl = new Date(leslieHitLvl4.getTime());
          toLvl4 = new Date(leslieHitLvl4.getTime());
          timeIncMins = 450;
          break;
        case 'Loot level V':
          if (leslieHitLvl5 == null) {
            leslieHitLvl5 = new Date();
          }
          leslieHitLvl4 = null;
          nextLvl = new Date(leslieHitLvl5.getTime());
          toLvl4 = new Date(leslieHitLvl5.getTime());
          timeIncMins = 0;
          break;
        default:
          leslieHitLvl1 = leslieHitLvl2 = leslieHitLvl3 = leslieHitLvl4 = leslieHitLvl5 = null;
      }

      if (nextLvl != null) {
        nextLvl.setMinutes(nextLvl.getMinutes() + timeIncMins);
      }
      if (toLvl4 != null) {
        toLvl4.setMinutes(nextLvl.getMinutes() + toLvl4Mins);
      }
    }
  }

  if (timeLeftStr == null) {
    //Use toLvl4Mins to get timeLeftStr...
    console.log(current_time() + " Time until (1): " + JSON.stringify(hospData));
    if (hospData.hoursLeft && hospData.minsLeft == 1) {
      hospData.hoursLeft -= 1;
      hospData.minsLeft = 0;
      console.log(current_time() + " Time until (2): " + JSON.stringify(hospData));
    } else if (hospData.hoursLeft && !hospData.minsLeft) {
      hospData.hoursLeft -= 1;
      hospData.minsLeft = 59;
      console.log(current_time() + " Time until (3): " + JSON.stringify(hospData));
    } else if (hospData.minsLeft > 0 && !hospData.hoursLeft) {
      hospData.minsLeft -= 1;
      console.log(current_time() + " Time until (4): " + JSON.stringify(hospData));
    } 

    if (hospData.hoursLeft < 0 || hospData.minsLeft < 0) {
      console.log(current_time() + ": uh-oh! " + JSON.stringify(hospData)); // Break here...
    }

    if (!hospData.hoursLeft && !hospData.minsLeft && !hospData.secsLeft) {
      hospData.hoursLeft = Math.floor(toLvl4Mins / 60);
      hospData.minsLeft = toLvl4Mins % 60;
      hospData.secsLeft = 1; // Used to indicate we've been here already
      console.log(current_time() + "Time until (5): " + JSON.stringify(hospData));
    }

    if (hospData.hoursLeft < 0 || hospData.minsLeft < 0) {
      console.log(current_time() + ": Oh no! " + JSON.stringify(hospData)); // Break here...
    }

    timeLeftStr = toHhMmSs(hospData.hoursLeft, hospData.minsLeft, hospData.secsLeft);
  }

  notificationDetails.message = 
        'Life: ' + nextLvlStruct.lifeStr;
  if (validPointer(nextLvl) && hospData.inHosp) {
    notificationDetails.message = notificationDetails.message +
        '\nOut of hosp at ' + nextLvl.toLocaleTimeString();
  } else if (validPointer(nextLvl) && options.nextLevel) {
    notificationDetails.message = notificationDetails.message +
        '\nNext level at ' + nextLvl.toLocaleTimeString();
  } else if (validPointer(toLvl4) && options.atLevelIV) {
    notificationDetails.message = notificationDetails.message +
        '\nLevel IV at ' + nextLvl.toLocaleTimeString();
  } else if (options.untilLevelIV) {
    if (validPointer(toLvl4)) {
      timeLeftStr = dateDifference(new Date(), toLvl4);
    }
    notificationDetails.message = timeLeftStr + ' until Level IV';
  }

  if (userId.name != hospData.name) {
    console.log(current_time() + ": oops - invalid params"); // Break here
  }

nextLvlStruct.nextLvl = nextLvl;
nextLvlStruct.nextLvlStr = nextLvlStr;
}

/*************************************************************************************/
/*
/* Function to load options from storage, as saved by options.js, presented bu
/* options.html. Basically just copied into a global options struct here. This
/* will call te main function in it's async complete callback.
/*
/************************************************************************************/

function loadOptions() {
  chrome.storage.sync.get({
      apiKey: null,
      Duke: true,
      Leslie: true,
      levelI: true,
      levelII: true,
      levelIII: true,
      levelIV: true,
      levelV: true,
      hosp: true,
      notifyTimeout: 10,
      nextLevel: true,
      atLevelIV: false,
      untilLevelIV: false,
      autoAttack: false
  }, 
  function(items) { // null = all items
    for (var i = 0; i<userIDs.length; i++) {
      switch (userIDs[i].name) {
         case "Duke":
           userIDs[i].enabled = items.Duke;
           break;
         case "Leslie":
           userIDs[i].enabled = items.Leslie;
           break;
      }

    options.apiKey = items.apiKey;
    options.notifyHosp = items.hosp;
    options.notifyLvlI = items.levelI;
    options.notifyLvlII = items.levelII;
    options.notifyLvlIII = items.levelIII;
    options.notifyLvlIV = items.levelIV;
    options.notifyLvlV = items.levelV;
    options.notifyTimeout = items.notifyTimeout;
    options.nextLevel = items.nextLevel;
    options.atLevelIV = items.atLevelIV;
    options.untilLevelIV = items.untilLevelIV;
    options.autoAttack = items.autoAttack;
    }

  // Now we can do the real stuff.
  loadOptionsComplete();
  });
}

