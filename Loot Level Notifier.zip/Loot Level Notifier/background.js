// Create our 1-minute alarm to fire off our API call and notifications
chrome.alarms.create(
  "xedx-loot-level", 
  {
    delayInMinutes: 1,
    periodInMinutes: 1
  }
);

chrome.alarms.onAlarm.addListener(function(alarm) {
  if (alarm.name === "xedx-loot-level") {
    onAlarm();
  }
});

// Check a ptr for undefined/null
function validPointer(val, dbg = false) {
  if (val == 'undefined' || typeof val == 'undefined' || val == null) {
    if (dbg) {
      // debugger; // Is this supported in extensions?
    }
      return false;
    }
        
    return true;
} 

// Global var that saves time left in hosp.
var dukeOutOfHosp = null;
var leslieOutOfHosp = null;

// GLobal vars for query and options
var apiKey = '4ZMAvIBON4zZLrd9';
var userIDs = 
    [{name: 'Duke',       ID: '4',  statusCell: 'C2', lvlCell: 'D2', enabled: true}, 
     {name: 'Leslie',     ID: '15', statusCell: 'C3', lvlCell: 'D3', enabled: true}];

var options = 
  {
  'notifyHosp': true,
  'notifyLvlI': true,
  'notifyLvlII': true,
  'notifyLvlIII': true,
  'notifyLvlIV': true,
  'notifyLvlV': true,
  'notifyTimeout': 10 // In seconds
  };

function onAlarm() {
  /*
  var apiKey = '4ZMAvIBON4zZLrd9';
  var userIDs = 
    [{name: 'Duke',       ID: '4',  statusCell: 'C2', lvlCell: 'D2', enabled: true}, 
     {name: 'Leslie',     ID: '15', statusCell: 'C3', lvlCell: 'D3', enabled: true}];
  */

  // This call is async, so we can't do any real work until it completes.
  loadOptions();
}
 
function loadOptionsComplete() { 
  var query = "";
  var notificationShown = false;
  var notificationDetails = {
    type: "basic",
    title: "Loot Level Checker",
    message: "Primary message to display",
    iconUrl: "icon_128.png"
  };
  
  for (var i = 0; i<userIDs.length; i++) {
    // See if our options are configured to display for this NPC
    if (userIDs[i].enabled == false) {
      console.log("Notifications not enabled for NPC " + userIDs[i].name);
      continue;
    }

    // Query basic stats to get NPC's status
    var ID = userIDs[i].ID;
    var url = "https://api.torn.com/user/" + ID + "?selections=basic&key=" + apiKey;
    var value = ImportJSON(url, query, "noHeaders,noTruncate");     

    // We should make from here a 'importJsonComplete()' fn,
    // and call when async XMLHttpRequest completes.
    // eg: function inportJsonComplete(...) {           
    var statusStr = value[0][4];
    if (!validPointer(statusStr)) {
      continue;
    }

    // Do same to get life current/max
    var lifeCurr = 0;
    var lifeMax = 0;
    var dbgLootLvl = "";
    var dbgMisc = "";
    var lifeStr = "";
    url = "https://api.torn.com/user/" + ID + "?selections=profile&key=" + apiKey;
    value = ImportJSON(url, query, "noHeaders,noTruncate");
    if (value != null) {
      lifeCurr = value[0][16];
      lifeMax = value[0][17];
      dbgLootLvl = value[0][22]; // Same as statusStr? Seems to be
      dbgMisc = value[0][23];
      lifeStr = lifeCurr + "/" + lifeMax;
    }

    var end = -1;
    var start = -1;
    var inHosp = false;
    var hoursLeft = 0;
    var minsLeft = 0;
    var secsLeft = 0;
    if ((start = statusStr.indexOf('In hospital for ')) != -1) {
      inHosp = true;
      end = statusStr.indexOf(' hrs ');
      if (end != -1) {
        hoursLeft = statusStr.slice(start+16, end);
        start = end+6;
        end = statusStr.indexOf(' mins');
        if (end != -1) {
           minsLeft = statusStr.slice(start, end);
        }
      } else {
        end = statusStr.indexOf(' mins');
        if (end != -1) {
           minsLeft = statusStr.slice(start+16, end);
        } else {
          end = statusStr.indexOf(' secs');
          if (end != -1) {
            secsLeft = statusStr.slice(start+16, end);
          }
        }
      }
 
      // Log this event and save time until released.
      if (hoursLeft > 0) {
          notificationDetails.message = userIDs[i].name + ' is in hosp for ' +
                hoursLeft + ' hours, ' + minsLeft + ' minutes.';
        } else if (minsLeft > 0) {
          notificationDetails.message = userIDs[i].name + ' is in hosp for ' +
                minsLeft + ' minutes.';
        } else if (secsLeft > 0) {
          notificationDetails.message = userIDs[i].name + ' is in hosp for ' +
                secsLeft + ' seconds.';
        }

      console.log(notificationDetails.message);  
      var now = new Date();
      now.setHours(now.getHours() + hoursLeft); 
      now.setMinutes(now.getMinutes() + minsLeft);
      if (userIDs[i].name == "Duke") {
        dukeOutOfHosp = new Date(now.getTime());   
      } else {
        leslieOutOfHosp = new Date(now.getTime()); 
      } 
    } else {
      inHosp = false;
    }

    end = statusStr.indexOf(',');
    var status = statusStr;
    var lootLvl = '<unknown loot level>';
    if (end != -1) {
      status = statusStr.slice(0, end);
      lootLvl = statusStr.slice(end+1);
    }
    
    if (!inHosp) {
      notificationDetails.message = userIDs[i].name + ' is at ' + lootLvl;
    }
    console.log("onAlarm: raw data (statusStr) = " + statusStr);
    console.log("onAlarm: message = " + notificationDetails.message);

    var iconUrlStr = "icon_128.png";
    if (userIDs[i].name == "Duke") {
      iconUrlStr = "https://profileimages.torn.com/50c3ed98-ae8f-311d-4.png";
    } else if (userIDs[i].name == "Leslie") {
      iconUrlStr = "https://profileimages.torn.com/4d661456-746e-b140-15.png";
    }

    
    // loot levels increase after 30, 90, 210 and 450 minutes
    if (dukeOutOfHosp != null) {
      var dukeLvl4 = new Date(dukeOutOfHosp.getTime());
      dukeLvl4.setHours(dukeLvl4.getMinutes() + 210);
      console.log("Duke at level IV at: " + dukeLvl4.toLocaleString());
    }

    if (leslieOutOfHosp != null) {
      var leslieLvl4 = new Date(leslieOutOfHosp.getTime());
      leslieLvl4.setHours(leslieLvl4.getMinutes() + 210); 
      console.log("Leslie at level IV at: " + leslieLvl4.toLocaleString()); 
    }  

    // Needs decrease of indent (by 2)
      if (inHosp) {
        var dateStr = (userIDs[i].name == "Duke") ? 
                  dukeOutOfHosp.toLocaleString() : 
                  leslieOutOfHosp.toLocaleString();
        var msg = userIDs[i].name + ' gets out of hosp at ' + dateStr;
      
        console.log(msg);
        if (!options.notifyHosp) {
          console.log("Not notifying, in hosp");
          continue;
        }
      }

      // loot levels increase after 30, 90, 210 and 450 minutes
      var nextLvlTime = 0;
      if (lootLvl == 'Loot level I') {
        if (!options.notifyLvlI) {
          console.log("Not notifying, lvl I");
          continue;
        }
        nextLvlTime = 30;
      }
      if (lootLvl == 'Loot level II') {
        if (!options.notifyLvlII) {
          console.log("Not notifying, lvl II");
          continue;
        }
      nextLvlTime = 90;
      }
      if (lootLvl == 'Loot level III') {
        if (!options.notifyLvlIII) {
          console.log("Not notifying, lvl III");
          continue;
        }
      nextLvlTime = 120;
      }
      if (lootLvl == 'Loot level IV') {
        if (!options.notifyLvlIV) {
          console.log("Not notifying, lvl IV");
          continue;
        }
      nextLvlTime = 450;
      }
      if (lootLvl == 'Loot level V' && !options.notifyLvlV) {
        console.log("Not notifying, lvl V");
        continue;
      }

      if (userIDs[i].name == "Duke" && dukeOutOfHosp != null) {
        var nextLvl = new Date(dukeOutOfHosp.getTime());
        nextLvl.setHours(nextLvl.getMinutes() + 30);
        notificationDetails.message = notificationDetails.message +
            '\nNext level at ' + nextLvl 
      } else if (userIDs[i].name == "Leslie" && leslieOutOfHosp != null) {
        var nextLvl = new Date(leslieOutOfHosp.getTime());
        nextLvl.setHours(nextLvl.getMinutes() + 30);
        notificationDetails.message = notificationDetails.message +
            '\nNext level at ' + nextLvl 
      }

      notificationDetails.message = notificationDetails.message +
            '\nLife: ' + lifeStr;

      console.log(current_time() + ": Creating notification, message: " +
                  notificationDetails.message);
      chrome.notifications.getPermissionLevel(permissionLevelCallback);
      chrome.notifications.onButtonClicked.addListener(onClickCallback);
      chrome.notifications.onClosed.addListener(onClickCallback);
      chrome.notifications.create(userIDs[i].name, 
                                  {type: "basic",
                                   title: "Loot Level Checker",
                                   message: notificationDetails.message,
                                   iconUrl: iconUrlStr,
                                   requireInteraction: true,
                                   buttons: [{
                                       title: "Attack"
                                    }]
                                  },
                                  creationCallback);
      notificationShown = false;
    // End needs decrease of indent
  } // end 'for' loop
}

function creationCallback(id) {
  //var text = current_time() + ": Creating notification for " + id;
  if (validPointer(chrome.runtime.lastError)) {
    var text = current_time() + ": Creating notification for " + id + 
               ", lastError = " + chrome.runtime.lastError;
    console.log(text);
  }

  // Automatically close/clear after 10 seconds
  setTimeout(function(){
    console.log(current_time() + ": notification timing out (closing), id = " + id);
    chrome.notifications.clear(id);}, options.notifyTimeout*1000);
}

function onClickCallback(id, index) {
  console.log(current_time() + ": notification onClickCallback" +
                               " ID=" + id + " Index=" + index);
  if (index == 0) { // Attack button
    var done = false;
    for (var i = 0; i<userIDs.length && !done; i++) {
      if (userIDs[i].name == id) {
        var url = "https://www.torn.com/loader.php?sid=attack&user2ID=" +
          userIDs[i].ID;
        chrome.tabs.create({url: url});
        done = true;
      }
    }
  }
}

function permissionLevelCallback(level) {
  console.log("notification permission level = " + level);
}

// Return current time string
function current_time() {
 return new Date().toLocaleTimeString(); 
}

function loadOptions() {
  chrome.storage.sync.get({
      Duke: true,
      Leslie: true,
      levelI: true,
      levelII: true,
      levelIII: true,
      levelIV: true,
      levelV: true,
      hosp: true,
      notifyTimeout: 10
  }, 
  function(items) { // null = all items
    for (var i = 0; i<userIDs.length; i++) {
      switch (userIDs[i].name) {
         case "Duke":
           userIDs[i].enabled = items.Duke;
           break;
         case "Leslie":
           userIDs[i].enabled = items.Leslie;
           break;
      }

    options.notifyHosp = items.hosp;
    options.notifyLvlI = items.levelI;
    options.notifyLvlII = items.levelII;
    options.notifyLvlIII = items.levelIII;
    options.notifyLvlIV = items.levelIV;
    options.notifyLvlV = items.levelV;
    options.notifyTimeout = items.notifyTimeout;
    }

  // Now we can do the real stuff.
  loadOptionsComplete();
  });
}

